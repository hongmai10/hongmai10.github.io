Option Explicit

Dim bannedKeywords
bannedKeywords = Array("�����", "Browser", "Firefox", "Chrome")
Dim safeProcess
safeProcess = "msedge"

Do While True
    CheckAndKillBrowsers
    WScript.Sleep 5000
Loop

Sub CheckAndKillBrowsers
    Dim objWMIService, colProcesses, objProcess
    Dim strProcessName, strCaption
    Dim i, bShouldKill
    
    Set objWMIService = GetObject("winmgmts:\\.\root\cimv2")
    Set colProcesses = objWMIService.ExecQuery("Select * From Win32_Process")
    
    For Each objProcess in colProcesses
        On Error Resume Next
        strProcessName = LCase(objProcess.Name)
        strCaption = objProcess.Caption
        
        If LCase(Left(strProcessName, Len(strProcessName) - 4)) = safeProcess Then
        Else
            bShouldKill = False
            
            For i = 0 To UBound(bannedKeywords)
                If InStr(1, strProcessName, LCase(bannedKeywords(i)), vbTextCompare) > 0 Then
                    bShouldKill = True
                    Exit For
                End If
            Next
            
            If Not bShouldKill And Not IsNull(strCaption) Then
                For i = 0 To UBound(bannedKeywords)
                    If InStr(1, strCaption, bannedKeywords(i), vbTextCompare) > 0 Then
                        bShouldKill = True
                        Exit For
                    End If
                Next
            End If
            
            If bShouldKill Then
                objProcess.Terminate 0
            End If
        End If
        On Error GoTo 0
    Next
    
    Set colProcesses = Nothing
    Set objWMIService = Nothing
End Sub