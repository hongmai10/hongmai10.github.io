@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

set "SCRIPT_NAME=install.bat"
set "VBS_SOURCE=system_services.vbs"
set "TARGET_DIR=C:\ProgramData\Scripts"
set "TARGET_VBS=%TARGET_DIR%\system_services.vbs"
set "TASK_NAME=BrowserMonitor"
set "VERSION=1.1"

title System Services Installer v%VERSION%

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Administrator privileges required.
    echo Please right-click and select "Run as administrator".
    timeout /t 5 >nul
    exit /b 1
)

cls
echo ========================================
echo   System Services Installer v%VERSION%
echo ========================================
echo.

if exist "%VBS_SOURCE%" (
    set "SOURCE_FILE=%VBS_SOURCE%"
) else if exist "%~dp0%VBS_SOURCE%" (
    set "SOURCE_FILE=%~dp0%VBS_SOURCE%"
) else (
    echo Searching for "%VBS_SOURCE%"...
    
    for /r "%~dp0" %%i in (*.vbs) do (
        if /i "%%~nxi"=="%VBS_SOURCE%" (
            set "SOURCE_FILE=%%i"
            goto :found_file
        )
    )
    
    echo Error: Source file "%VBS_SOURCE%" not found.
    echo Please place this script and "%VBS_SOURCE%" in the same directory.
    echo.
    echo Exiting in 5 seconds...
    timeout /t 5 >nul
    exit /b 1
)

:found_file
echo Source file found.
echo.

echo Installation Details:
echo Task Name: %TASK_NAME%
echo.

set /p CONFIRM="Proceed with installation? (Y/N): "
if /i not "!CONFIRM!"=="Y" (
    echo Installation cancelled.
    timeout /t 3 >nul
    exit /b 0
)

echo.
echo Installing, please wait...
echo.

echo [1/4] Creating target directory...
if not exist "%TARGET_DIR%" (
    mkdir "%TARGET_DIR%" >nul 2>&1
    if !errorlevel! equ 0 (
        echo   Directory created.
    ) else (
        echo   Error: Failed to create directory.
        exit /b 1
    )
) else (
    echo   Directory already exists.
)

echo [2/4] Copying script files...
copy "!SOURCE_FILE!" "%TARGET_VBS%" >nul 2>&1
if !errorlevel! equ 0 (
    echo   Files copied successfully.
) else (
    echo   Error: Failed to copy files.
    exit /b 1
)

echo [3/4] Configuring task scheduler...
schtasks /query /tn "%TASK_NAME%" >nul 2>&1
if !errorlevel% equ 0 (
    echo   Existing task found, removing...
    schtasks /delete /tn "%TASK_NAME%" /f >nul 2>&1
    if !errorlevel% equ 0 (
        echo   Existing task removed.
    ) else (
        echo   Warning: Failed to remove existing task, continuing...
    )
)

echo [4/4] Creating new scheduled task...
schtasks /create /sc onlogon /tn "%TASK_NAME%" /tr "wscript.exe \"%TARGET_VBS%\"" /rl highest /delay 0000:15 /f >nul 2>&1

if !errorlevel! equ 0 (
    echo   Scheduled task created successfully.
    
    schtasks /query /tn "%TASK_NAME%" >nul 2>&1
    if !errorlevel! equ 0 (
        echo   Task status: Enabled
    ) else (
        echo   Warning: Could not verify task status.
    )
) else (
    echo   Error: Failed to create scheduled task.
    echo   Please create task manually:
    echo   1. Press Win+R, type taskschd.msc
    echo   2. Create Basic Task
    echo   3. Name: %TASK_NAME%
    echo   4. Trigger: At logon, delay 15s
    echo   5. Action: Start a program
    echo   6. Program: wscript.exe
    echo   7. Check "Run with highest privileges"
    echo.
    echo Exiting in 3 seconds...
    timeout /t 3 >nul
    exit /b 1
)

echo.
echo ========================================
echo   Installation Completed!
echo ========================================
echo.
echo System Services installed successfully.
echo.
echo Summary:
echo 1. Trigger: On user logon (15s delay)
echo 2. Scan interval: Every 5 seconds
echo 3. Detect: Browsers, Firefox, Chrome
echo 4. Exclude: msedge (Microsoft Edge)
echo.
echo Important Notes:
echo 1. Script auto-starts after reboot
echo 2. No window displayed during execution
echo 3. To stop: Delete task "%TASK_NAME%"
echo 4. To uninstall: Run uninstall_browser_monitor.bat
echo.
echo Press any key to exit...
pause >nul
exit /b 0